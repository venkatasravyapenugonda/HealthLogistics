import { Component, OnInit } from '@angular/core';
import { HealthService } from '../health.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor(private service:HealthService,private router:Router) { }
model:any={};
result:boolean=false;
//code for adding the new user
addUser():any{
  this.result=true;
  this.service.addUserRegister(this.model).subscribe();

}
gohome():any{
  
  this.router.navigate(['/home'])
}
  ngOnInit() {
  }

}
