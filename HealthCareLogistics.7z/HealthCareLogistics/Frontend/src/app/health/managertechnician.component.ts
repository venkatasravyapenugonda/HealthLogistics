import { Component, OnInit } from '@angular/core';
import { HealthService } from '../health.service';

@Component({
  selector: 'app-managertechnician',
  templateUrl: './managertechnician.component.html',
  styleUrls: ['./managertechnician.component.css']
})
export class ManagertechnicianComponent implements OnInit {
result:boolean=false;
  constructor(private service:HealthService,) { }
  model:any={};
  //method for adding new technician
  addTechnician(){
    this.result=true;
    this.service.addTechnician(this.model).subscribe();
  }

  ngOnInit() {
  }

}
