package com.cg.healthcarelogistics.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.healthcarelogistics.dao.TechnicianDao;
import com.cg.healthcarelogistics.dto.TechnicianRole;
import com.cg.healthcarelogistics.dto.Tests;
import com.cg.healthcarelogistics.dto.UserRegistration;

@Service
public class TechnicianServiceImpl implements TechnicianService{

	@Autowired
	TechnicianDao managerDao;
	@Override
	public TechnicianRole addTechnician(TechnicianRole managerRole) {
		return managerDao.addTechnician(managerRole);
	}

	@Override
	public List<TechnicianRole> getAllTechnician() {
		return managerDao.getAllTechnician();
	}

	@Override
	public void updateTechnician(Long mobile, Integer salary, Integer experience) {
		managerDao.updateTechnician(mobile, salary, experience);
		
	}

	@Override
	public void deleteTechnician(Long mobileNo) {
		managerDao.deleteTechnician(mobileNo);
		
	}

	@Override
	public boolean getTechnicianDetails(Long mobile, String password) {
		return managerDao.getTechnicianDetails(mobile, password);
	}

		

}
