import { Component, OnInit } from '@angular/core';
import { HealthService } from '../health.service';

@Component({
  selector: 'app-technicianacceptreject',
  templateUrl: './technicianacceptreject.component.html',
  styleUrls: ['./technicianacceptreject.component.css']
})
export class TechnicianacceptrejectComponent implements OnInit {
  result1:any=[];
  data:any=[];
  val1:any=[];
  mob:number;
  clickingstatus:boolean=false;
  resulting:string="your booking is accepted"
  constructor(private service:HealthService) { }

acceptBooking(email){
this.clickingstatus=true;
  console.log("in technician")
  console.log("user mailid is:"+email)
  this.service.acceptingbooking(email,this.clickingstatus);
  
  
}

  ngOnInit() {
    
     console.log("getting details in technician"+this.service.getBookedUsers(this.service.technicianMail))
      return this.service.getBookedUsers(this.service.technicianMail).subscribe((result1:any)=>{
        this.val1=result1;
      })
      }
    }
    
    



