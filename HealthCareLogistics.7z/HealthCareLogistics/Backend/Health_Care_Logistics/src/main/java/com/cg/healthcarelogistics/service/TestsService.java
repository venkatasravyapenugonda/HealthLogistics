package com.cg.healthcarelogistics.service;

import java.util.List;

import com.cg.healthcarelogistics.dto.Tests;
import com.cg.healthcarelogistics.dto.UserRegistration;

public interface TestsService {
	public Tests addTest(Tests test);
	public void updateTest(Long testId,Integer price);
	public List<Tests> getAllTests();
	public void deleteTest(Long testId);
	

}
